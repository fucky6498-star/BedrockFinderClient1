package id.bedrockfinder.client;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;

public class MainActivity extends Activity {
    LinearLayout root;
    EditText xInput, zInput;
    TextView chunkResult, status;
    int chosenColor = Color.CYAN;
    String chosenBlock = "Diamond Ore";

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        root.setBackgroundColor(Color.rgb(18, 22, 30));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("BEDROCK FINDER CLIENT", 24, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView subtitle = text("Standalone utility • Android • v1.0", 13, Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        addGap(16);

        section("BLOCK TRACERS — SETTINGS");
        Spinner blocks = new Spinner(this);
        String[] blockNames = {
            "Diamond Ore", "Ancient Debris", "Chest", "Trapped Chest", "Barrel",
            "Shulker Box", "Amethyst Block", "Deepslate", "Spawner", "Ender Chest",
            "Gold Ore", "Iron Ore", "Emerald Ore", "Redstone Ore", "Lapis Ore"
        };
        blocks.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, blockNames));
        root.addView(blocks);
        blocks.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { chosenBlock = blockNames[pos]; }
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });

        Spinner colors = new Spinner(this);
        String[] colorNames = {"Cyan", "Red", "Blue", "Green", "Purple", "Yellow", "White", "Orange", "Pink"};
        colors.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, colorNames));
        root.addView(colors);
        colors.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                int[] cs = {Color.CYAN, Color.RED, Color.BLUE, Color.GREEN, 0xFF9C27B0, Color.YELLOW, Color.WHITE, 0xFFFF9800, 0xFFE91E63};
                chosenColor = cs[pos];
                status.setText("Selected: " + chosenBlock + " • " + colorNames[pos] +
                    "\\nNote: settings are saved in this screen only; no live Minecraft block-reading is connected.");
                status.setTextColor(chosenColor);
            }
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });
        addToggle("Block Tracers", false, "UI prototype only — does not draw tracers inside Minecraft.");
        addToggle("Storage Finder", false, "A standalone APK cannot see game-world chest data without game integration.");
        addGap(12);

        section("CHUNK FINDER");
        TextView info = text("Enter your in-game X and Z coordinates to calculate the chunk. This does not scan hidden blocks or discover bases on a server.", 14, Color.LTGRAY);
        root.addView(info);
        xInput = edit("X coordinate");
        zInput = edit("Z coordinate");
        root.addView(xInput);
        root.addView(zInput);
        Button calc = button("CALCULATE CHUNK");
        root.addView(calc);
        chunkResult = text("Chunk: —", 17, Color.CYAN);
        root.addView(chunkResult);
        calc.setOnClickListener(v -> calculateChunk());
        addToggle("Show chunk-boundary guide", false, "Calculates chunk coordinates only; it does not overlay the game.");
        addToggle("Amethyst / geode notes", false, "Amethyst geodes are not a reliable indicator of a player base.");
        addGap(12);

        section("CAMERA / BASE TOOLS");
        addToggle("Freecam", false, "Requires integration with the game engine; this standalone app cannot move Minecraft's camera.");
        addToggle("Base Finder", false, "No live world scanner is connected. Use observations from your own world.");
        addToggle("Deepslate area notes", false, "Deepslate alone does not prove a base is underneath.");
        addGap(12);

        section("STATUS");
        status = text("Ready. Choose a block and color above.", 14, Color.WHITE);
        status.setPadding(dp(12), dp(12), dp(12), dp(12));
        status.setBackgroundColor(Color.rgb(32, 39, 52));
        root.addView(status);

        TextView foot = text("\\nImportant: this is a buildable starter app with working UI and chunk-coordinate calculation. It is not an injected Minecraft client; Freecam, ESP/tracers, and hidden-base scanning require a compatible in-game integration and cannot be enabled by a standalone APK alone.", 12, Color.LTGRAY);
        root.addView(foot);
    }

    void section(String s) {
        TextView t = text(s, 16, 0xFF64D8CB);
        t.setPadding(0, dp(8), 0, dp(8));
        root.addView(t);
    }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        return t;
    }
    void addGap(int h) { View v = new View(this); root.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setPadding(dp(10), dp(4), dp(10), dp(4));
        e.setBackgroundColor(Color.rgb(37, 44, 58));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.setMargins(0, dp(4), 0, dp(4)); e.setLayoutParams(lp);
        return e;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF00796B));
        return b;
    }
    void addToggle(String name, boolean on, String note) {
        Switch sw = new Switch(this); sw.setText(name); sw.setTextSize(15); sw.setTextColor(Color.WHITE);
        sw.setChecked(on); sw.setPadding(0, dp(8), 0, dp(4)); root.addView(sw);
        TextView n = text(note, 12, Color.LTGRAY); n.setPadding(dp(4), 0, 0, dp(6)); root.addView(n);
        sw.setOnCheckedChangeListener((buttonView, checked) -> {
            if (status != null) status.setText(name + ": " + (checked ? "ON" : "OFF") +
                "\\n" + (checked ? note : "Disabled."));
        });
    }
    void calculateChunk() {
        try {
            int x = Integer.parseInt(xInput.getText().toString().trim());
            int z = Integer.parseInt(zInput.getText().toString().trim());
            int cx = Math.floorDiv(x, 16), cz = Math.floorDiv(z, 16);
            int bx = cx * 16, bz = cz * 16;
            chunkResult.setText("Chunk: (" + cx + ", " + cz + ")" +
                "\\nChunk X range: " + bx + " to " + (bx + 15) +
                "\\nChunk Z range: " + bz + " to " + (bz + 15));
        } catch (Exception e) {
            chunkResult.setText("Enter valid X and Z coordinates first.");
        }
    }
}
